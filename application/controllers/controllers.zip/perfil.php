<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Perfil extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('Model_Usuarios');
		$this->load->model('Model_Empresa');
	}
	public function index()
	{
		if($this->session->userdata('logueado')){
			$this->load->view('head/head_profile');
			$data["datos"]=$this->Model_Empresa->datosPerfil($this->session->userdata('IDEmpresa'));
			$this->load->view('helper/titulo',$data);
			$this->load->view('views/perfil',$data);
			$this->load->view('footer');
		}else{
			redirect('');
		}
		
		
		
	}
}
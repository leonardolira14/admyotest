<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Registro extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('Model_Registro');
		$this->load->model('Model_Usuarios');
	}
	public function index()
	{
		if($this->session->userdata('logueado')){
			$this->load->view('head/head_profile');
		}else{
			$this->load->view('head/head');
		}
		
		$respuesta["estados"]=$this->Model_Registro->getEstados();	
		$respuesta["sector"]=$this->Model_Registro->getSector();
		$this->load->view('views/registro',$respuesta);
		$this->load->view('footer');
	}
	public function getSubsector(){
		$subsector=json_decode($_POST["datos"]);
		$respuesta=$this->Model_Registro->getSubSector($subsector->sector);
		$dat=[];
		foreach ($respuesta->result() as $key=>$value) {
			array_push($dat,array("nombre"=>$respuesta->result()[$key]->Giro,"numero"=>$respuesta->result()[$key]->IDNivel2));
		}
		$datos["subnivel"]=$dat;
		echo json_encode($datos);
		//var_dump($respuesta->result());
	}
	public function getrama(){
		$subsector=json_decode($_POST["datos"]);
		$respuesta=$this->Model_Registro->getRama($subsector->rama);
		$dat=[];
		foreach ($respuesta->result() as $key=>$value) {
			array_push($dat,array("nombre"=>$respuesta->result()[$key]->Giro,"numero"=>$respuesta->result()[$key]->IDNivel2));
		}
		$datos["rama"]=$dat;
		echo json_encode($datos);
		//var_dump($respuesta->result());
	}
	//funcion para login
	public function login(){
		$datos=json_decode($_POST["datos"]);
		$respuesta["ad"]=$this->Model_Usuarios->login($datos->a,$datos->b);
		if($respuesta["ad"]!=false){
			$datost["pass"]=1;
			$datost["token"]=$this->Model_Usuarios->addAcceso($respuesta["ad"]->result()[0]->IDUsuario);
			$datost["datos"]=$respuesta["ad"];
			$usuario_data=array(
				"IDUsuario"=>$respuesta["ad"]->result()[0]->IDUsuario,
				"IDEmpresa"=>$respuesta["ad"]->result()[0]->IDEmpresa,
				"token"=>$datost["token"],
				'logueado'=>TRUE
			);
			$this->session->set_userdata($usuario_data);
		}else{
			$datost["pass"]=2;
			$datost["datos"]="Error de usuario o contraseña";
			
		}
		echo json_encode($datost);
		
	}
	public function cerrar_session(){
		$data["token"]=$this->session->userdata("token");
		$this->Model_Usuarios->cierraSession($data);
		$usuario_data=array('logueado'=>FALSE);
		$this->session->set_userdata($usuario_data);
		$this->session->sess_destroy();
		$datos["pass"]=1;
		echo json_encode($datos);

	}
	
}
<style>
	.f-1{
		background-color: rgba(0, 0, 0, 0);
		background-repeat: no-repeat;
		background-image: url(assets/img/slider/contactanos-admyo-4.jpg);
		background-size: cover;
		background-position: center center;
		height: 400px;
		opacity: 1;
		visibility: inherit;
	}
	

</style>
<div class="container-fluid">
	<div class="row f-1">

		<div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6  margin-bottom-30 div-txt text-center">
			<div class="div-1 align-middle">CONTACTA CON </div>
			<div class="div-2 align-middle">NOSOTROS</div>
			<div class="div-3 align-middle">SI TIENES CUALQUIER </div>
			<div class="div-4 align-middle">DUDA SOBRE EL FUNCIONAMIENTO</div>
		</div>
		<div class="col-6 div-imgd">
			<img src="<?= base_url(); ?>assets/img/slider/imagen-banner-4.png"  class="img-fluid">
		</div>
	</div>	
</div>
<div class="container margin-top-30">
	<div class="row" >
		<div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6 info-box">

			<div class="info-icon">
				<i class="fa fa-envelope bgblue-1 white"></i>
			</div>
			<div class="info-content">
				<div class="info-title">
					<h6>email</h6>
				</div>
				<div class="info-disc">
					<p>info@admyo.com</p>
				</div>
			</div>
		</div>
		<div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6  info-box">
			<div class="info-icon">
				<i class="fa fa-map-marker bgblue-1 white"></i>
			</div>
			<div class="info-content">
				<div class="info-title">
					<h6>DIRECCIÓN</h6>
				</div>
				<div class="info-disc">
					<p>Newton 57 A, Polanco, México D.F. C.P. 11560</p>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="container margin-top-30 margin-bottom-30">
	<div class="row" >
	
		  <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
		  	<div id="" class="form-group">
		     <input type="text" class="form-control" id="" placeholder="Nombre"> 
		  </div>
		  </div>
		  <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
		  	<div id="" class="form-group">
		     <input type="text" class="form-control" id="" placeholder="E-mail"> 
		  </div>
		  </div>
		  <div class="col-12 col-sm-12 col-md-6 col-lg-6 col-xl-6">
		  	<div id="" class="form-group">
		     <input type="text" class="form-control" id="" placeholder="Asusnto"> 
		  </div>
		  </div>
		  <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
		  	<div id="" class="form-group">
		     <textarea class="form-control" placeholder="Mensaje"  name="" id="" cols="30" rows="10"></textarea>
		  </div>
		  </div>
		   <div class="col-12 col-sm-12 col-md-4 col-lg-4 col-xl-4 align-center btn btn-primary">
		  		ENVIAR
		  </div>

	</div>
</div>
<div class="container-fluid">
	<div class="row">
		<div id="map" class="col-12 margin-top-30 margin-bottom-40 ng-scope">
	<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2237.224475606228!2d-99.19202855315021!3d19.431922491916666!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85d2020072bb5bf7%3A0x1a8b83a233c91060!2sAv.+Isaac+Newton+57%2C+Polanco+V+Secc%2C+11560+Ciudad+de+M%C3%A9xico%2C+D.F.!5e0!3m2!1ses-419!2smx!4v1478559265141" width="100%" height="100%" frameborder="0" style="border:0" allowfullscreen=""></iframe>
		</div>
	</div>
</div>

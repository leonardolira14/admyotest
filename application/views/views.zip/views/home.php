<script src='<?= base_url(); ?>assets/css/slick/slick.min.js'></script>
<link rel='stylesheet prefetch' href='<?= base_url(); ?>assets/css/slick/slick.css'>
<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/css/slick/slick-theme.css"/>
<style>	
	.variable-width{
		margin-top: 20px;
		margin-bottom: 20px;
	}
	.slick-slide {
		float: left;
		height: auto;
		min-height: 1px;
		margin-left: 20px;
		color: #fff;
		text-align: center;
	}
	.cuadroazul{
		position: absolute;
		max-width: 250px;
		max-height: 250px;
		height: 39%;
		width: 39%;
		top: 16%;
		left: 2%;
	}
	.cuadrogris{
		    position: absolute;
    max-width: 250px;
    max-height: 250px;
    height: 39%;
    width: 39%;
    top: 41%;
    left: 14%;
	}
	
	
	

</style>
<script>
	$(function(){
		$("#que-gano").iziModal({
			title: 'ADMYO',
			headerColor: '#005d8f',
			fullscreen: true,
			
		});
		
		$('div[llc="carrusel"]').slick({
			infinite: true,
			slidesToShow: 3,
			slidesToScroll: 1,
			autoplay: true,
			autoplaySpeed: 2000,
			variableWidth: true
		});
		
		
	})
</script>
<div class="container-fluid">
	<div class="row">
		<div class="col-6">
			<div class="cuadroazul text-center">
				<img src="<?= base_url(); ?>/assets/img/cuadro-azul.png" class='img-fluid' alt="">
				
			</div>
			
			<img src="<?= base_url(); ?>/assets/img/mujer-registro-admyo.png" class='img-fluid' alt="">
		</div>
		<div class="col-6">
		<div class="cuadrogris text-center">
				<img src="<?= base_url(); ?>/assets/img/cuadro-gris.png" class='img-fluid' alt="">
				
			</div>
			<img src="<?= base_url(); ?>/assets/img/hombre-login-admyo.png" class='img-fluid' alt="">
		</div>		
	</div>

</div>
<div class="container margin-bottom-40">
	<div class="row align-items-center">
		<div class="col col-12 col-sm-12 col-md-6">
			<video class="video-1" src="<?= base_url(); ?>/assets/video/fondo-video3.mp4"></video>
		</div>
		<div class="col col-12 col-sm-12 col-md-6">
			<div class="cuadroazul-bl text-center align-self-center">
				<span class="">¿QUÉ GANAS PARTICIPANDO EN ADMYO?</span>
				<p class="margin-top-10"><span ><i onclick=" $('#que-gano').iziModal('open');" class="fa fa-plus-circle" aria-hidden="true"></i></span>
					<br><span class="">VER MAS</span></p>
				</div>
			</div>
		</div>	
	</div>
	<div class="container-fluid mas-calificadas">
		<div class="row  align-items-center " >
			<div class="col-12  text-center">
				<div class="div-tx align-middle align-center">EMPRESAS MEJOR CALIFICADAS</div>
				<div class="col-11 align-center">
					<div class="variable-width" llc="carrusel" style="overflow: hidden;">
						<div> <div class="contn"><img src="<?=  base_url(); ?>/assets/img/logosEmpresas/280.jpeg" class="img-fluid container-carrucel__image" ></div></div>
						<div> <div class="contn"><img src="<?=  base_url(); ?>/assets/img/logosEmpresas/280.jpeg" class="img-fluid container-carrucel__image" ></div></div>
						<div> <div class="contn"><img src="<?=  base_url(); ?>/assets/img/logosEmpresas/280.jpeg" class="img-fluid container-carrucel__image" ></div></div>
						<div> <div class="contn"><img src="<?=  base_url(); ?>/assets/img/logosEmpresas/280.jpeg" class="img-fluid container-carrucel__image" ></div></div>
						<div> <div class="contn"><img src="<?=  base_url(); ?>/assets/img/logosEmpresas/280.jpeg" class="img-fluid container-carrucel__image" ></div></div>
						<div> <div class="contn"><img src="<?=  base_url(); ?>/assets/img/logosEmpresas/280.jpeg" class="img-fluid container-carrucel__image" ></div></div>
						<div> <div class="contn"><img src="<?=  base_url(); ?>/assets/img/logosEmpresas/280.jpeg" class="img-fluid container-carrucel__image" ></div></div>
						<div> <div class="contn"><img src="<?=  base_url(); ?>/assets/img/logosEmpresas/280.jpeg" class="img-fluid container-carrucel__image" ></div></div>
						<div> <div class="contn"><img src="<?=  base_url(); ?>/assets/img/logosEmpresas/280.jpeg" class="img-fluid container-carrucel__image" ></div></div>
						<div> <div class="contn"><img src="<?=  base_url(); ?>/assets/img/logosEmpresas/280.jpeg" class="img-fluid container-carrucel__image" ></div></div>
						<div> <div class="contn"><img src="<?=  base_url(); ?>/assets/img/logosEmpresas/280.jpeg" class="img-fluid container-carrucel__image" ></div></div>
						<div> <div class="contn"><img src="<?=  base_url(); ?>/assets/img/logosEmpresas/280.jpeg" class="img-fluid container-carrucel__image" ></div></div>
						<div> <div class="contn"><img src="<?=  base_url(); ?>/assets/img/logosEmpresas/280.jpeg" class="img-fluid container-carrucel__image" ></div></div>
						<div> <div class="contn"><img src="<?=  base_url(); ?>/assets/img/logosEmpresas/280.jpeg" class="img-fluid container-carrucel__image" ></div></div>
					</div>
				</div>

			</div>
			<div class="col-12  text-center">
				<div class="div-tx align-middle align-center">EMPRESAS QUE MÁS CALIFICAN</div>
				<div class="col-11 align-center">
					<div class="variable-width" llc="carrusel" style="overflow: hidden;">
						<div> <div class="contn"><img src="<?=  base_url(); ?>/assets/img/logosEmpresas/280.jpeg" class="img-fluid container-carrucel__image" ></div></div>
						<div> <div class="contn"><img src="<?=  base_url(); ?>/assets/img/logosEmpresas/280.jpeg" class="img-fluid container-carrucel__image" ></div></div>
						<div> <div class="contn"><img src="<?=  base_url(); ?>/assets/img/logosEmpresas/280.jpeg" class="img-fluid container-carrucel__image" ></div></div>
						<div> <div class="contn"><img src="<?=  base_url(); ?>/assets/img/logosEmpresas/280.jpeg" class="img-fluid container-carrucel__image" ></div></div>
						<div> <div class="contn"><img src="<?=  base_url(); ?>/assets/img/logosEmpresas/280.jpeg" class="img-fluid container-carrucel__image" ></div></div>
						<div> <div class="contn"><img src="<?=  base_url(); ?>/assets/img/logosEmpresas/280.jpeg" class="img-fluid container-carrucel__image" ></div></div>
						<div> <div class="contn"><img src="<?=  base_url(); ?>/assets/img/logosEmpresas/280.jpeg" class="img-fluid container-carrucel__image" ></div></div>
						<div> <div class="contn"><img src="<?=  base_url(); ?>/assets/img/logosEmpresas/280.jpeg" class="img-fluid container-carrucel__image" ></div></div>
						<div> <div class="contn"><img src="<?=  base_url(); ?>/assets/img/logosEmpresas/280.jpeg" class="img-fluid container-carrucel__image" ></div></div>
						<div> <div class="contn"><img src="<?=  base_url(); ?>/assets/img/logosEmpresas/280.jpeg" class="img-fluid container-carrucel__image" ></div></div>
						<div> <div class="contn"><img src="<?=  base_url(); ?>/assets/img/logosEmpresas/280.jpeg" class="img-fluid container-carrucel__image" ></div></div>
						<div> <div class="contn"><img src="<?=  base_url(); ?>/assets/img/logosEmpresas/280.jpeg" class="img-fluid container-carrucel__image" ></div></div>
						<div> <div class="contn"><img src="<?=  base_url(); ?>/assets/img/logosEmpresas/280.jpeg" class="img-fluid container-carrucel__image" ></div></div>
						<div> <div class="contn"><img src="<?=  base_url(); ?>/assets/img/logosEmpresas/280.jpeg" class="img-fluid container-carrucel__image" ></div></div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="container testimoniales margin-top-40" >
		<div class="row">
			<div class="col-12 col-12 col-12 text-center">
				<span class="align-center">TESTIMONIALES</span>
				<br>
				<img src="<?=  base_url(); ?>/assets/img/pleca-títulos.png" class="align-center" alt="">
				<div class="services-wrap ">
					<div class="service-tag">
						<img src="<?=  base_url(); ?>/assets/img/services-tag.png" alt="services tag">
					</div>
					<ul class="feature-textimoniales clearfix">
						<div class=" col-12">
							<div class="service-box bgwhite shadow-2">
								<li class="test-div col-12 col-sm-12 col-md-4 col-lg-4 col-xl-4">
									<div class="service-icon">
										<center><img class='img-fluid' src="<?=  base_url(); ?>/assets/img/testimonial/th1.png"></center>
									</div>
									<div class="service-title">
										<h5>LITHO OFFSET ANDINA, S.A. DE C.V. (México)</h5>
									</div>
									<div class="service-disc">
										<p>“Con admyo un nuevo cliente me ha podido encontrar y no me ha dado problemas con el pago”</p>
									</div>
								</li>
								<li class="test-div col-12 col-sm-12 col-md-4 col-lg-4 col-xl-4">
									<div class="service-icon">
										<center><img src="<?=  base_url(); ?>/assets/img/testimonial/th3.png" class='img-fluid'></center>
									</div>
									<div class="service-title">
										<h5>Netmar S.A. de C.V. (México)</h5>
									</div>
									<div class="service-disc">
										<p>“Con la reputación que me han dado mis clientes he podido generar una cuenta importante”</p>
									</div>
								</li>
								<li class="test-div col-12 col-sm-12 col-md-4 col-lg-4 col-xl-4">							
									<div class="service-icon">
										<center><img class='img-fluid' src="<?=  base_url(); ?>/assets/img/testimonial/th2.png"></center>
									</div>
									<div class="service-title">
										<h5>Matas Lorenzo (México)</h5>
									</div>
									<div class="service-disc">
										<p>“He podido recuperar una cuenta morosa gracias a la presión y seguimiento que le ha dado admyo”</p>
									</div>
								</li>
							</div>
						</div>	
					</ul>
				</div>
			</div>
		</div>
	</div>
<div id="que-gano">
  <img id="adentroims" src="<?= base_url(); ?>/assets/img/Infografia-Admyo.jpg" class="img-fluid align-center" alt="">
</div>

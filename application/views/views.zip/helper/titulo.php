<div class=" div-invisible-sm container titempresa <?= $datos["class"];?> ">
	<div class="row ">
		<div class="col-2 ">
			<img src="<?= base_url()?>/assets/img/iconoadmyo-blanco-opaco.png" class="img-fluid">
		</div>
		<div class="col-10 nombre-empresa ">
		<span  style="font-size:<?= $datos["tmletra"]?> " >
			<?= $datos["titulo"]; ?>
			</span>	
		</div>
	</div>
</div>


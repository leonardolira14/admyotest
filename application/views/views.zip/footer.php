<script>
	$(function(){
		$("#msjerror").iziModal({
			title: 'Mensaje de Admyo',
			 headerColor: 'rgba(230, 0, 0, 0.68)',
			pauseOnHover: true,
		    timeoutProgressbarColor: 'rgba(255,255,255,0.5)',
		    transitionIn: 'comingIn',
		    transitionOut: 'comingOut',
		     timeout: 6000,
		     timeoutProgressbar: true,

		})
	})
</script>
<div class="container-fluid   footer">
	<div class="row barraazul ">
			<div class="col text-center align-middle"><i class="fa fa-linkedin align-middle" aria-hidden="true"></i></div>
			<div class="col text-center align-middle"><i class="fa fa-twitter align-middle" aria-hidden="true"></i></div>
			<div class="col text-center align-middle"><i class="fa fa-facebook align-middle" aria-hidden="true"></i></div>
	</div>
	<div class="row barranegra">
				<div   class="  col text-center align-middle"><span class="link" llc="terminosycondiciones" >Términos y Condiciones</span></div>
				 
				<div   class="col text-center align-middle"><span class="link" llc="puntosydescuentos" >Puntos y Descuentos</span></div>
				 
				<div   class="col text-center align-middle"><span class="link" llc="saladeprensa">Sala de Prensa</span></div>
				
				<div  class="col text-center align-middle"><span class="link" llc="contacto">Contácto</span></div>	
	</div>
	<div class="row barranegra">	
		<div class="col text-center align-middle">	<span class="power">© POWERED BY ZTARK</span></div>
	</div>
</div>
<div id="msjerror">
</div>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Admyo | Reputación Empresarial</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<link rel="stylesheet" href="<?= base_url(); ?>/assets/css/bootstrap.css">
	<link rel="stylesheet" href="<?= base_url(); ?>/assets/css/general.css">
	<link rel="stylesheet" href="<?= base_url(); ?>/assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="<?= base_url(); ?>/assets/css/iziModal.min.css">
	<link rel="stylesheet" href="<?= base_url(); ?>/assets/css/responsive.css">
	<link rel="stylesheet" href="<?= base_url(); ?>/assets/css/menu.css">

	<link href="https://fonts.googleapis.com/css?family=Montserrat|Prosto+One" rel="stylesheet">
	<script src="<?=  base_url(); ?>/assets/js/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
	<script src="<?=  base_url(); ?>/assets/js/iziModal.min.js"></script>
	<script src="<?=  base_url(); ?>/assets/js/helper.js"></script>

</head>
<script>
var ayuda=new helper();
$(document).on('click','.link',function(){
		if($(this).attr("llc")=="login"){
		$("#mod-login").iziModal('open');
		$(".list-menus").toggle('fast')
		if(ayuda.getlocal("dats")){
					var lin=ayuda.getlocal("dats");
					console.log(lin);
					d=lin.split("|");
					$("#mod-login #email").val(d[0]);
					$("#mod-login #clave").val(d[1]);
				}
		}else if($(this).attr("llc")=="olvide"){
			$("#mod-login").iziModal('close');
			$("#mod-olvide").iziModal('open')
		}else if($(this).attr('llc')=="cerrarsession"){
			ayuda.senddata('','registro/cerrar_session',function(data){
				var lin=JSON.parse(data);
				if(lin.pass==1){
					location.reload();
				}
			})
		}else{
			ayuda.goto($(this).attr("llc"));
		}

})
$(window).on('load',function(){
ayuda.preload();
})

</script>
<body>
<div id="preeload">
	<div class="col-12"><img src="<?= base_url(); ?>/assets/img/ajax-loader.gif" class="img-fluid align-center"></div>
</div>
<div class="container-fluid">
	<div class="row">
		<div class="col-12 plecaazul">
		</div>
	</div>
</div>
<div class="container margin-top-10">
	<div class="row">
		<div class="col-12 dec">
			<table class="float-right">
				<tr>
					<td style="color:#005d8f;cursor: pointer;">
						<i class="fa fa-bell" aria-hidden="true"></i>
					</td>
					<td>
						<div class="numnotif">12</div>
					</td>
					<td>
						<div llc="cerrarsession" class="btn btn-primary link"><i class="fa fa-times" aria-hidden="true"></i> Cerrar sessión</div>
					</td>
				</tr>
			</table>
		</div>
		<nav class="menu-pc div-invisible-sm wsmenu clearfix  margin-top-20">
			<div class="col-3 float-left">
				<img src="<?= base_url(); ?>/assets/img/logo-admyo2.png" class="img-fluid float-left " alt="ADMYO">
			</div>
			<div class="col-9 text-right float-right wsmenulist">
				<ul class="mobile-sub wsmenu-list float-right">
					
					<li><a href="">Mi Perfil</a>
						<ul class="wsmenu-submenu">
							<li>
								<a ui-sref="perfil" href="perfil">Mi perfil</a>
							</li>
							<li>
								<a ui-sref="perfil" href="perfil/calificacionesrecibidasc">Calificaciones Recibidas de Clientes</a>
								</li>
							<li>
								<a ui-sref="perfil" href="perfil/calificacionesrecibidasp">Calificaciones Recibidas de Proveedores</a>
								</li>
							<li>
								<a ui-sref="perfil" href="perfil/reputacionc">Reputación de Clientes</a>
								</li>
							<li>
								<a ui-sref="perfil" href="perfil/reputacionp">Reputación de Proveedores</a>
								</li>
							<li>
								<a ui-sref="perfil" href="perfil/calificacionesrealizadasc">Calificaciones Realizadas a Clientes</a>
								</li>
							<li>
								<a ui-sref="perfil" href="perfil/calificacionesrealizadasc">Calificaciones Realizadas a Proveedores</a>
							</li>
							<li>
								<a ui-sref="perfil" href="perfil/visitas">visitas</a>
							</li>
						</ul>
					</li>
					<li><a href="">mis datos</a>
						<ul class="wsmenu-submenu">
							<li>
								<a ui-sref="perfil" href="perfil/datosuaurio">Mi datos de usuario</a>
							</li>
							<li>
								<a ui-sref="perfil" href="perfil/contacto">Contacto</a>
								</li>
							<li>
								<a ui-sref="perfil" href="perfil/datosempresa">Datos de Empresa</a>
								</li>
							<li>
								<a ui-sref="perfil" href="perfil/usuariomaster">Usuario Master</a>
								</li>
							<li>
								<a ui-sref="perfil" href="perfil/productosyservicios">Productos Y servicios</a>
								</li>
							<li>
								<a ui-sref="perfil" href="perfil/certificaciones">Certificaciones </a>
							</li>
							<li>
								<a ui-sref="perfil" href="perfil/asociaciones">Asociaciones </a>
							</li>
						</ul>
					</li>
					<li><a href="">Perfil Buscado</a>
					<ul class="wsmenu-submenu">
							<li>
								<a ui-sref="perfil" href="/perfil">Perfil</a>
							</li>
							<li>
								<a ui-sref="perfil" href="/perfil">datos de empresa</a>
								</li>
							<li>
								<a ui-sref="perfil" href="/perfil">certificaciones</a>
								</li>
							<li>
								<a ui-sref="perfil" href="/perfil">asociaciones</a>
								</li>
							<li>
								<a ui-sref="perfil" href="/perfil">Calificaciones de Clientes</a>
								</li>
							<li>
								<a ui-sref="perfil" href="/perfil">calificaciones de proveedores</a>
							</li>
							<li>
								<a ui-sref="perfil" href="/perfil">Productos y Servicios </a>
							</li>
							<li>
								<a ui-sref="perfil" href="/perfil">Marcas</a>
							</li>
						</ul>
					</li>
					<li><a href="">Planes</a></li>
					
				</ul>
			</div>
		</nav>
		<div class="menu-sm div-visible-sm">
			<div class="col-12 col-xs-12 col-md-12 col-lg-12 col-xl-12 ">
				<img src="<?= base_url(); ?>/assets/img/logo-admyo2.png" class="img-fluid" alt="ADMYO">
			</div>
			<div class="col-12 col-xs-12 col-md-12 col-lg-12 col-xl-12 ">
				
			</div>
		</div>
		
	</div>
</div>
<div class="container-fluid">
	<div  class="row barraazul align-middle">
			<div class="col-10 align-center">
			      <div class="input-group mb-2 mb-sm-0">
			        <input type="text" class="form-control" id="inlineFormInputGroupUsername" placeholder="Buscar empresas, productos o servicios">
			        <div class="input-group-addon btn-buscar">BUSCAR</div>
			      </div>
			</div>
	</div>
</div>


